document.getElementById('cepForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const cepInput = document.getElementById('cep');
    const cep = cepInput.value;
    const resultCard = document.getElementById('result');
    const errorCard = document.getElementById('error');
    const loadingIndicator = document.getElementById('loading');

    resultCard.style.display = 'none';
    errorCard.style.display = 'none';
    loadingIndicator.style.display = 'block';

    if (cep.length !== 8 || isNaN(cep)) {
        errorCard.style.display = 'block';
        loadingIndicator.style.display = 'none';
        alert('O campo de CEP deve conter 8 dígitos e ser numérico.');
        cepInput.focus(); 
        return;
    }

    fetch(`https://viacep.com.br/ws/${cep}/json/`)
        .then(response => response.json())
        .then(data => {
            loadingIndicator.style.display = 'none';

            if (data.erro) {
                errorCard.style.display = 'block';
            } else {
                document.getElementById('cepResult').innerText = data.cep;
                document.getElementById('logradouro').innerText = data.logradouro;
                document.getElementById('bairro').innerText = data.bairro;
                document.getElementById('localidade').innerText = data.localidade;
                document.getElementById('uf').innerText = data.uf;

                resultCard.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Erro na consulta ao ViaCEP:', error);
            loadingIndicator.style.display = 'none';
            errorCard.style.display = 'block';
        });
});

window.onload = function() {
    document.getElementById('cep').focus();
};
